// AUTONOMÍA / Sendero Sonoro - Estación Medidor
// Lee el serial del Arduino, reproduce los .mp3 (carpeta "data") y muestra la interfaz.
// Librería: Sound. Cierra el Monitor Serie del Arduino IDE antes de correr.
//
// MODO SIMULACIÓN (SIMULAR = true): no necesita Arduino. Teclas:
//   1 = ESPERA    2 = MIDIENDO    3 = PESO:100    4 = PESO:500    5 = PESO:250
//   6 = META:100  7 = PASADO
import processing.serial.*;
import processing.sound.*;

final boolean SIMULAR = false;                // false cuando conectes el Arduino
final String PUERTO = "COM3";                 // ← puerto del Arduino

// Colores
final color C_FONDO   = color(16, 18, 30);
final color C_TEXTO  = color(240, 242, 250);
final color C_SUAVE   = color(130, 137, 170);
final color C_ESPERA  = color(120, 140, 255);   // azul violeta
final color C_MIDE    = color(255, 184, 77);    // ámbar
final color C_LISTO   = color(80, 220, 150);    // verde
final color C_PASADO  = color(255, 90, 100);    // rojo

Serial puerto;
ArrayList<String> cola = new ArrayList<String>();   // Nombres de archivo en espera
SoundFile sonando = null;

// Estado de la interfaz
String estado = "ESPERA";                     // ESPERA, MIDIENDO, LISTO o PASADO
int meta = 0;                                 // Meta en gramos que fijó el tag NFC (0 = sin tag)
String frase = "Pon el ingrediente en la pesa";
int pesoObjetivo = 0;
float pesoAnim = 0;                           // Número que "sube" hasta el peso real
int tiempoEstado = 0;                         // millis() al cambiar de estado

void setup() {
  size(900, 560);
  smooth(8);
  textFont(createFont("Arial", 32));
  if (!SIMULAR) {
    printArray(Serial.list());                // Puertos disponibles
    puerto = new Serial(this, PUERTO, 9600);  // Al abrirlo, el Arduino se reinicia (y hace tare)
    puerto.clear();
  }
}

void draw() {
  // Leer todas las líneas que lleguen
  if (!SIMULAR) {
    while (puerto.available() > 0) {
      String linea = puerto.readStringUntil('\n');
      if (linea == null) break;
      procesar(trim(linea));
    }
  }

  // Reproducir la cola, un clip tras otro
  if (sonando == null || !sonando.isPlaying()) {
    if (cola.size() > 0) {
      SoundFile s = clip(cola.remove(0));
      if (s != null) {
        sonando = s;
        s.play();
      }
    }
  }

  pesoAnim = lerp(pesoAnim, pesoObjetivo, 0.12);
  dibujar();
}

// ---------------------------------------------------------------- INTERFAZ

void dibujar() {
  background(C_FONDO);
  color c = colorEstado();

  // Encabezado mínimo
  textAlign(CENTER, CENTER);
  fill(C_SUAVE);
  textSize(14);
  text("AUTONOMÍA  ·  Medidor", width / 2.0, 36);

  // Círculo central
  float cx = width / 2.0, cy = 270;

  // Anillo base
  noFill();
  stroke(255, 25);
  strokeWeight(14);
  ellipse(cx, cy, 250, 250);

  strokeCap(ROUND);
  stroke(c);
  if (estado.equals("ESPERA")) {
    // Respira lento
    float p = 0.5 + 0.5 * sin(millis() * 0.003);
    strokeWeight(6 + 8 * p);
    stroke(red(c), green(c), blue(c), 120 + 135 * p);
    ellipse(cx, cy, 250, 250);
  } else if (estado.equals("MIDIENDO")) {
    // Arco que gira
    strokeWeight(14);
    float a = millis() * 0.006;
    arc(cx, cy, 250, 250, a, a + TWO_PI * 0.3);
    arc(cx, cy, 250, 250, a + PI, a + PI + TWO_PI * 0.1);
  } else if (estado.equals("PASADO")) {
    // Anillo rojo que parpadea
    float p = 0.5 + 0.5 * sin(millis() * 0.02);
    strokeWeight(14);
    stroke(red(c), green(c), blue(c), 110 + 145 * p);
    ellipse(cx, cy, 250, 250);
  } else {
    // Se completa el anillo al llegar a LISTO
    float t = constrain((millis() - tiempoEstado) / 600.0, 0, 1);
    strokeWeight(14);
    arc(cx, cy, 250, 250, -HALF_PI, -HALF_PI + TWO_PI * t);
  }
  noStroke();

  // Texto dentro del círculo
  if (estado.equals("LISTO")) {
    fill(C_TEXTO);
    textSize(92);
    text(round(pesoAnim), cx, cy - 12);
    fill(c);
    textSize(24);
    text("gramos", cx, cy + 60);
  } else if (estado.equals("PASADO")) {
    fill(C_TEXTO);
    textSize(40);
    text("¡Te pasaste!", cx, cy - 12);
    fill(c);
    textSize(20);
    text("meta: " + meta + " g", cx, cy + 36);
  } else if (estado.equals("MIDIENDO")) {
    fill(C_TEXTO);
    textSize(30);
    text("midiendo", cx, cy - 8);
    String puntos = "";
    for (int i = 0; i < (millis() / 400) % 4; i++) puntos += ".";
    fill(c);
    text(puntos, cx, cy + 28);
    if (meta > 0) {
      fill(C_SUAVE);
      textSize(16);
      text("meta: " + meta + " g", cx, cy + 62);
    }
  } else {
    fill(C_TEXTO);
    textSize(30);
    text(meta > 0 ? "meta: " + meta + " g" : "0 g", cx, cy - 8);
    fill(C_SUAVE);
    textSize(16);
    text(meta > 0 ? "echa el ingrediente" : "acerca un tag o pon algo", cx, cy + 30);
  }

  // Lo que se está diciendo
  fill(C_TEXTO);
  textSize(22);
  text(frase, cx, 480);
}

color colorEstado() {
  if (estado.equals("MIDIENDO")) return C_MIDE;
  if (estado.equals("LISTO")) return C_LISTO;
  if (estado.equals("PASADO")) return C_PASADO;
  return C_ESPERA;
}

// ------------------------------------------------------------ LÓGICA / AUDIO

void keyPressed() {
  if (!SIMULAR) return;
  if (key == '1') procesar("ESPERA");
  if (key == '2') procesar("MIDIENDO");
  if (key == '3') procesar("PESO:100");
  if (key == '4') procesar("PESO:500");
  if (key == '5') procesar("PESO:250");
  if (key == '6') procesar("META:100");
  if (key == '7') procesar("PASADO");
}

void procesar(String linea) {
  if (linea.length() == 0) return;
  println("Arduino: " + linea);
  if (linea.equals("ESPERA")) {
    cambiar("ESPERA", "Pon el ingrediente en la pesa");
    decir("espera.mp3");
  } else if (linea.equals("MIDIENDO")) {
    cambiar("MIDIENDO", "Espera, estoy midiendo");
    decir("midiendo.mp3");
  } else if (linea.startsWith("META:")) {
    meta = int(linea.substring(5));
    if (meta > 0) {
      cambiar("ESPERA", "Meta: " + meta + " gramos");
      if (dataFile("meta_" + meta + ".mp3").exists()) decir("meta_" + meta + ".mp3");
      else decir("espera.mp3");
    }
  } else if (linea.equals("PASADO")) {
    cambiar("PASADO", "Te pasaste");
    decir("te pasaste.mp3");
  } else if (linea.startsWith("PESO:")) {
    int g = int(linea.substring(5));
    pesoObjetivo = g;
    pesoAnim = 0;
    cambiar("LISTO", "Este peso es " + g + " gramos");
    decirPeso(g);
  }
}

void cambiar(String nuevo, String texto) {
  estado = nuevo;
  frase = texto;
  tiempoEstado = millis();
  if (!nuevo.equals("LISTO")) pesoObjetivo = 0;
}

// Corta lo que suena y arma una frase nueva
void decir(String... archivos) {
  cola.clear();
  if (sonando != null && sonando.isPlaying()) sonando.stop();
  for (String a : archivos) cola.add(a);
}

// "Este peso es" + número + "gramos"
void decirPeso(int g) {
  g = round(g / 10.0) * 10;                   // Redondea a múltiplos de 10
  if (dataFile("peso_" + g + ".mp3").exists()) {   // Clip con la frase completa
    decir("peso_" + g + ".mp3");
    return;
  }
  ArrayList<String> clips = new ArrayList<String>();
  clips.add("este_peso_es.mp3");

  if (g >= 1000) {
    clips.add("n1000.mp3");
  } else {
    int c = (g / 100) * 100;                  // Centenas
    int d = g % 100;                          // Decenas
    if (c == 100) clips.add(d == 0 ? "n100.mp3" : "n101.mp3");   // cien / ciento
    else if (c > 100) clips.add("n" + c + ".mp3");
    if (d > 0) clips.add("n" + d + ".mp3");
  }
  clips.add("gramos.mp3");
  decir(clips.toArray(new String[0]));
}

// Carga el clip nuevo cada vez (reusar uno detenido a veces no vuelve a sonar).
// Si falta el archivo, avisa y se salta (no se cae)
SoundFile clip(String archivo) {
  if (!dataFile(archivo).exists()) {
    println("FALTA el clip: " + archivo);
    return null;
  }
  return new SoundFile(this, archivo);
}
