// MEDIDOR DE COCINA - Arduino UNO + HX711 + buzzer (pin 8) + lector NFC RC522
// Manda por serial: ESPERA, MIDIENDO, PESO:250, META:100, PASADO, TAG:xxxxxxxx
// IMPORTANTE: reiniciar con la plataforma puesta y VACÍA (ahí hace el cero).
//
// CÓMO FUNCIONA CON NFC:
//   1) Acercas el tag -> el Arduino busca su ID en la tabla TAGS y fija la META (ej. 100 g).
//   2) Echan el ingrediente. Si el peso queda estable cerca de la meta -> LISTO.
//   3) Si se pasan de la meta -> PASADO (pitidos rápidos). Se arregla quitando peso o retirando todo.
//   Sin tag (meta = 0) funciona como antes: mide y dice el peso que haya.
//
// RC522 -> Arduino UNO (¡alimentar a 3.3V, NO a 5V!):
//   SDA(SS)=10  SCK=13  MOSI=11  MISO=12  RST=9  GND=GND  3.3V=3.3V
// Librerías: HX711 (Bogdan Necula) y MFRC522 (Miguel Balboa).
#include "HX711.h"
#include <SPI.h>
#include <MFRC522.h>

HX711 balanza;
MFRC522 rfid(10, 9);                         // SS = 10, RST = 9

const float FACTOR = 1049.0;                 // Factor calibrado con Calibracion.ino
const int BUZZER = 8;
const bool BUZZER_PASIVO = true;             // true si con HIGH no suena (usa tone)
const bool SIMULAR = false;                  // true = SIN celda ni lector: todo desde el Monitor Serie
                                             //   peso: escribe 230 y Enter (0 = retirar)
                                             //   tag:  escribe t100 y Enter (meta de 100 g)
const bool SOLO_NFC = false;                 // true = prototipo sin celda pero CON lector RC522 real:
                                             //   acercar un tag simula echar ese peso (pitidos que se
                                             //   aceleran -> tono continuo -> PESO:xxx). Requiere SIMULAR = false.
                                             // Poner false cuando esté lista la celda.

// Tabla de tags: ID -> gramos de meta. Para saber el ID de cada tag, acércalo
// (con SIMULAR = false) y mira "TAG:xxxxxxxx" en el Monitor Serie; cópialo aquí.
struct Tag { const char* uid; int gramos; };
const Tag TAGS[] = {
  { "F5C97E05", 100 },                       // Ficha 1: 100 g
  { "620493EE", 250 },                       // Ficha 2: 250 g
};
const int N_TAGS = sizeof(TAGS) / sizeof(TAGS[0]);

float pesoSimulado = 0;

const float UMBRAL_PESO   = 20.0;            // g mínimos para considerar que hay algo puesto
const float UMBRAL_RETIRO = 10.0;            // g por debajo de los cuales se considera retirado
const float TOLERANCIA    = 2.0;             // g de variación permitida para estable
                                             // (si el ruido no deja estabilizar, sube a 3 o 4)
const float MARGEN_META   = 10.0;            // g de margen alrededor de la meta (±10 g = alcanzada)
const float CAMBIO_LISTO  = 15.0;            // g de cambio en LISTO para volver a medir
const unsigned long TIEMPO_ESTABLE = 2000;   // ms que debe estar estable

enum Estado { ESPERANDO, MIDIENDO, LISTO, PASADO };
Estado estado = ESPERANDO;

int meta = 0;                                // Meta en gramos (0 = sin tag)
float pesoRef = 0;                           // Peso de referencia para medir estabilidad
unsigned long inicioEstable = 0;

void beep(int ms) {
  if (BUZZER_PASIVO) {
    tone(BUZZER, 2000, ms);
    delay(ms);
  } else {
    digitalWrite(BUZZER, HIGH);
    delay(ms);
    digitalWrite(BUZZER, LOW);
  }
}

void pitar() { beep(600); }                  // Listo: un pitido largo

void alertaPasado() {                        // Te pasaste: tres pitidos rápidos
  for (int i = 0; i < 3; i++) {
    beep(150);
    delay(100);
  }
}

// Prototipo sin celda: simula echar el ingrediente hasta la meta.
// Pitidos cada vez más rápidos -> tono continuo -> listo.
void simularLlenado(int g) {
  Serial.println("MIDIENDO");
  for (int pausa = 700; pausa > 80; pausa -= 70) {
    beep(60);
    delay(pausa);
  }
  beep(1200);                                // Tono continuo: llegaste al peso
  Serial.print("PESO:");
  Serial.println(g);
  delay(4000);                               // Tiempo para que la interfaz diga el peso
  Serial.println("ESPERA");
}

// Fija una meta nueva (solo si está esperando). La misma ficha de nuevo la cancela.
void aplicarMeta(int g) {
  if (estado != ESPERANDO || g <= 0) return;
  if (!SOLO_NFC && g == meta) {              // Misma ficha otra vez: cancela la meta (medida libre)
    meta = 0;
    Serial.println("META:0");
    Serial.println("ESPERA");
    beep(80);
    delay(100);
    beep(80);                                // Dos pitidos cortos: meta cancelada
    return;
  }
  meta = g;
  Serial.print("META:");
  Serial.println(meta);
  beep(150);                                 // Pitido corto: tag leído
  if (SOLO_NFC) {
    delay(1500);                             // Pausa: "ahora echa el ingrediente"
    simularLlenado(g);
    meta = 0;
    Serial.println("META:0");
  }
}

void revisarTag() {
  if (SIMULAR) return;
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;

  String uid = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(rfid.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();

  Serial.print("TAG:");
  Serial.println(uid);                       // Útil para copiar el ID a la tabla
  for (int i = 0; i < N_TAGS; i++) {
    if (uid.equals(TAGS[i].uid)) {
      aplicarMeta(TAGS[i].gramos);
      return;
    }
  }
}

// Pasa a MIDIENDO tomando el peso actual como referencia
void empezarAMedir(float peso) {
  estado = MIDIENDO;
  pesoRef = peso;
  inicioEstable = millis();
  Serial.println("MIDIENDO");
}

void volverAEsperar() {
  estado = ESPERANDO;
  if (meta != 0) {
    meta = 0;
    Serial.println("META:0");
  }
  Serial.println("ESPERA");
}

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER, OUTPUT);
  if (!SIMULAR) {
    SPI.begin();
    rfid.PCD_Init();
    rfid.PCD_DumpVersionToSerial();          // Diagnóstico: debe decir "Firmware Version: 0x92" (o 0x91)
    if (!SOLO_NFC) {
      balanza.begin(2, 3);                   // DT = pin 2, SCK = pin 3
      balanza.set_scale(FACTOR);
      delay(1000);
      balanza.tare();                        // Cero con la plataforma vacía
    }
  }
  beep(200);                                 // Pitido de arranque: el buzzer y el código funcionan
  Serial.println("ESPERA");
}

void loop() {
  float peso;
  if (SIMULAR) {
    if (Serial.available()) {
      if (Serial.peek() == 't') {            // Tag simulado: t100
        Serial.read();
        aplicarMeta(Serial.parseInt());
      } else {                               // Peso escrito a mano
        pesoSimulado = Serial.parseFloat();
      }
      while (Serial.available()) Serial.read();
    }
    peso = pesoSimulado;
    delay(100);
  } else {
    revisarTag();
    if (SOLO_NFC) return;                    // Sin celda: todo ocurre al leer el tag
    if (!balanza.is_ready()) return;
    peso = balanza.get_units(5);             // Promedio de 5 lecturas (~0.5 s)
  }

  switch (estado) {
    case ESPERANDO:
      if (peso > UMBRAL_PESO) {              // Pusieron algo
        empezarAMedir(peso);
      }
      break;

    case MIDIENDO:
      if (peso < UMBRAL_RETIRO) {            // Lo quitaron antes de terminar (la meta se conserva)
        estado = ESPERANDO;
        Serial.println("ESPERA");
      } else if (meta > 0 && peso > meta + MARGEN_META) {
        estado = PASADO;                     // Se pasaron de la meta
        alertaPasado();
        Serial.println("PASADO");
      } else if (fabs(peso - pesoRef) > TOLERANCIA) {
        pesoRef = peso;                      // Aún cambia: reinicia el conteo
        inicioEstable = millis();
      } else if (millis() - inicioEstable >= TIEMPO_ESTABLE) {
        // Estable 2 segundos. Con meta, solo vale si está cerca de ella.
        if (meta == 0 || peso >= meta - MARGEN_META) {
          estado = LISTO;
          pesoRef = peso;
          pitar();
          Serial.print("PESO:");
          Serial.println(meta > 0 ? meta : (int)round(peso));
        } else {
          inicioEstable = millis();          // Falta ingrediente: sigue esperando
        }
      }
      break;

    case LISTO:
      if (peso < UMBRAL_RETIRO) {            // Retiraron el ingrediente
        volverAEsperar();
      } else if (fabs(peso - pesoRef) > CAMBIO_LISTO) {
        empezarAMedir(peso);                 // Cambiaron el peso sin retirar: medir de nuevo
      }
      break;

    case PASADO:
      if (peso < UMBRAL_RETIRO) {            // Retiraron todo
        volverAEsperar();
      } else if (peso <= meta + MARGEN_META - 3) {
        empezarAMedir(peso);                 // Quitaron un poco y ya no se pasa
      }
      break;
  }
}
